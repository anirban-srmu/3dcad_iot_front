export interface EnvConfig{
    BaseEndpoint?: string,
}