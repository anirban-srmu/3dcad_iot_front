export type Configuration = {
    BaseEndpoint:string;
    versionName:string;
    releaseDate:string;
  }