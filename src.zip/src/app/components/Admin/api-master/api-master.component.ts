import { Component } from '@angular/core';

@Component({
  selector: 'app-api-master',
  standalone: true,
  imports: [],
  templateUrl: './api-master.component.html',
  styleUrl: './api-master.component.scss'
})
export class ApiMasterComponent {

}
